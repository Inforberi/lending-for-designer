// // при нажатии на сенсор кнопка увеличивается и уменьшается через какое то время функция

// const transitionTouchBtn = (btn) => {
//     btn.style.transform = 'translateY(-3px) scale(1.05)';
//     btn.style.transition = '.5s ease';
//     setTimeout(() => {
//         btn.style.transform = 'none';
//     }, 500);
// };
