// const headerBtnTransition = document.querySelector('header__button');

// if (window.innerWidth <= 980) {
//     headerBtnTransition.addEventListener('click', () => {
//         transitionTouchBtn(headerBtnTransition);
//     });
// }
